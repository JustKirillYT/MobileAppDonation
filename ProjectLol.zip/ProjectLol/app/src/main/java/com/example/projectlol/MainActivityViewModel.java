package com.example.projectlol;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivityViewModel extends ViewModel {
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>();
    private final FirebaseAuth auth = FirebaseAuth.getInstance();

    public void userLogin(String email, String password) {
        auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(task -> {
            if (task.isSuccessful())
            {
                Log.println(Log.ASSERT,"Successful login","Успешный вход!");
            }
            else
            {
                Exception e = task.getException();
                Log.println(Log.ASSERT,"Successful login","Успешный вход!");
            }
        });
    }
    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

}
