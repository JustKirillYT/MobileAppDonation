package com.example.projectlol;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

public class MainActivity extends AppCompatActivity {

    EditText editEmail;
    EditText editPassword;
    Button buttonLogin;
    Button buttonToRegisterActivity;
    TextView textViewError;


    @SuppressLint("CutPasteId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editEmail = findViewById(R.id.field_passwordToLogin);
        editPassword = findViewById(R.id.field_passwordToLogin);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonToRegisterActivity = findViewById(R.id.buttonToRegisterActivity);
        MainActivityViewModel vm = new ViewModelProvider(this).get(MainActivityViewModel.class);

        buttonLogin.setOnClickListener(v -> {
            String email = editEmail.getText().toString();
            String password = editPassword.getText().toString();
            vm.userLogin(email,password);

        });

        buttonToRegisterActivity.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterView.class);
            startActivity(intent);
        });


    }

}